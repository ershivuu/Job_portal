import React from "react";
import "./MasterJobProfile.css";

function MasterJobProfile() {
  return (
    <>
  
    </>
  );
}

export default MasterJobProfile;
