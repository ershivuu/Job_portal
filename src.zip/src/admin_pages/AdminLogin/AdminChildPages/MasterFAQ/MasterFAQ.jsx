import React from 'react'
import "./MasterFAQ.css"

function MasterFAQ() {
  return (
    <div>
      <p>hello FAQ hello FAQ hello FAQ hello FAQ hello FAQ</p>
    </div>
  )
}

export default MasterFAQ
