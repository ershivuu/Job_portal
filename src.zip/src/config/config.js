// export const BASE_URL = "http://192.168.1.8:8090/v1/api";
export const CANDIDATE_BASE_URL = "http://192.168.1.18:8090/v1/api";

export const ADMIN_BASE_URL = "http://192.168.1.18:8090/v1/api";
